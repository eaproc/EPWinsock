﻿Imports System.Net.Sockets
Imports System.Net


''' <summary>
''' Bi-Functional Class. Acting as Server or as Client
''' </summary>
''' <remarks>Server Listens on Local IP: 127.0.0.1</remarks>
Public Class EPWinSockOld
    REM Perhaps, Server Listening on Local IP will solve the multi-adapter issue
    REM In as much you can get to the machine you should always get a response ..  regardless of the route you are taking


#Region "Constructors"




#End Region


#Region "Enums"

    ''' <summary>
    ''' Socket Connection States
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum SocketConnectionState
        Connected
        Disconnected
        Connecting
        Listening
    End Enum

    ''' <summary>
    ''' Which Mode will this Control Act as
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum SocketConnectionMode
        Server
        Client
    End Enum

    ''' <summary>
    ''' Socket Connection Protocol
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum SocketConnectionProtocol
        TCP
        REM For now TCP Only
    End Enum


#End Region


#Region "Events"



    ''' <summary>
    ''' Raised when the state of this socket changes
    ''' </summary>
    ''' <param name="CurrentState"></param>
    ''' <param name="DebugMessage"></param>
    ''' <remarks></remarks>
    Public Event SocketStateChanged(ByVal CurrentState As SocketConnectionState,
                                    ByVal DebugMessage As String)


#End Region




#Region "Properties"


    ''' <summary>
    ''' The acting socket as client or server for this class
    ''' </summary>
    ''' <remarks></remarks>
    Private sckSocket As Socket




    ''' <summary>
    ''' For Now I will be exposing the Protocols supported by this control
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ConnectionProtocol As SocketConnectionProtocol = SocketConnectionProtocol.TCP





    ''' <summary>
    ''' The container for this control
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ControlContainer As Control = Nothing

    ''' <summary>
    ''' Pass out the connection state
    ''' </summary>
    ''' <remarks></remarks>
    Private _ConnectionState As SocketConnectionState = SocketConnectionState.Disconnected

    ''' <summary>
    ''' Socket Connection State
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property ConnectionState As SocketConnectionState
        Get
            Return Me._ConnectionState
        End Get
    End Property



    ''' <summary>
    ''' If this is a server .. then fetch the list of connected clients
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property ConnectedClients As List(Of Object)
        Get
            Return Nothing
        End Get
    End Property


    ''' <summary>
    ''' If this is a client .. Then you need the server IP to Connect to Server
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ServerIP As String

    ''' <summary>
    ''' Ranges between 1 to 32767
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Port As Int16 = 2000



    ''' <summary>
    ''' Listening on Default Local IP
    ''' </summary>
    ''' <remarks></remarks>
    Public Const LocalIP As String = "127.0.0.1"



#End Region



#Region "Methods"


    ''' <summary>
    ''' Converts my exposed protocols to Standard Protocol Enumerations
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getSelectedProtocol() As ProtocolType
        Select Case Me.ConnectionProtocol
            Case Is = SocketConnectionProtocol.TCP
                Return ProtocolType.Tcp
        End Select

        Return ProtocolType.Tcp

    End Function


    ''' <summary>
    ''' Make Server Available For Connections
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ServerGoOnline() As Boolean
        'We are running on port 1300
        '

        '   *Possible Errors*
        '   Socket 1300 Already in USE
        '   Socket is Already in Listening State

        REM Check if the Server IP is in correct format else raise error


        Try
            Dim IEndpt As IPEndPoint = New IPEndPoint(IPAddress.Parse(Me.ServerIP), Me.Port)

            Me.sckSocket = New Socket(IEndpt.AddressFamily, SocketType.Stream, Me.getSelectedProtocol)
            Me.sckSocket.Bind(IEndpt)
            '
            'Allow Maximum 100 Pending Connections
            '
            Me.sckSocket.Listen(100)
            ' Return ServerKeepAccepting()

        Catch ex As Exception


        End Try

        Return False
    End Function

    Private Function ServerGoOffline() As Boolean
        '   Since am using lsvMainClients to store the connected clients directly
        '   Saving their socket information in each item

        '   So if Server is to go offline, First 
        '   Block incoming and outgoing transaction on server
        '   Stop listening

        'I am thinking of not disposing clients here even though server is shutdown
        'Because they have nothing in common. Server Shutdown only means no more accepting new connection
        '
        'Clients can be shutdown from options on client or when it goes off
        '
        '' ''   Now Remove and Dispose Each item on the list
        '' ''       On Dispose of each item, let them dispose their socket indexes


        Try
            With Me.sckSocket
                '' Only use shutdown for a connected Socket. Not a listening socket
                '.Shutdown(SocketShutdown.Both)
                .Close()



            End With
            Return True

        Catch ex As Exception

        End Try
        Return False
    End Function











    ''' <summary>
    ''' Starts the socket
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub [Start]()

    End Sub

    ''' <summary>
    ''' Stops the Socket
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub [Stop]()




    End Sub



#End Region




End Class
