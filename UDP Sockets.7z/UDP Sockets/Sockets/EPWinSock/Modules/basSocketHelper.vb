﻿Imports System.Net.Sockets
Imports System.Text

''' <summary>
''' Controls sending and fetching information from sockets
''' </summary>
''' <remarks></remarks>
Module basSocketHelper


    ''' <summary>
    ''' The delimiter I will be using throughout the program for delimiting commands sent via socks
    ''' </summary>
    ''' <remarks></remarks>
    Public Const DelimiterUsedForCommands As String = "|||"

    ''' <summary>
    ''' Send Message Accross Sockets USing commands
    ''' </summary>
    ''' <param name="Sock"></param>
    ''' <param name="Message"></param>
    ''' <param name="CommandName"></param>
    ''' <param name="Delimiter"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function SendCommand(ByVal Sock As Socket,
                                ByVal Message As String,
                                Optional ByVal CommandName As String = vbNullString,
                                Optional ByVal Delimiter As String = DelimiterUsedForCommands
                                                               ) As Boolean

        If Sock.Connected Then
            Try
                Dim BytesSent As Integer = Sock.Send(
                                    Encoding.ASCII.GetBytes(
                                                    String.Format(
                                                        "{0}{1}{2}",
                                                        CommandName,
                                                        Delimiter,
                                                        Message
                                                        )
                                                )
                                    )

                'Just for debugging
                ' Debug.Print(BytesSent)
                Return True
            Catch ex As Exception

            End Try

        End If

        Return False
    End Function

    ''' <summary>
    ''' Collects Information From Socket Class and Split it with delimiter. Leaving the first index as the command
    ''' </summary>
    ''' <param name="ByteRecieved"></param>
    ''' <param name="SockClass"></param>
    ''' <param name="Delimiter"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function ReceiveCommand(ByVal ByteRecieved As Integer,
                                   ByRef SockClass As clsClientSocketContainer,
                               Optional ByVal Delimiter As String = DelimiterUsedForCommands
                                                              ) As String()

        Return Split(
                Encoding.ASCII.GetString(SockClass.buffer, 0, ByteRecieved),
                Delimiter
                                )
    End Function


End Module
