﻿Imports System.Net.Sockets
Imports System.Net
Imports System.ComponentModel


''' <summary>
''' Bi-Functional Class. Acting as Server or as Client
''' </summary>
''' <remarks>Server Listens on Local IP: 127.0.0.1 by default</remarks>
Public Class EPWinSock
    Implements IComponent


    REM Perhaps, Server Listening on Local IP will solve the multi-adapter issue
    REM In as much you can get to the machine you should always get a response ..  regardless of the route you are taking


#Region "Constructors"

    Sub New()

        Me.ClientsOnSever = New SortedList(Of Integer, clsClientSocketContainer)(Me.Maximum_Connection_Allowed)

    End Sub

    Sub New(ByVal mContainer As IContainer)

        Me.New()


        Me.ParentControl_IContainer = mContainer


    End Sub


#End Region


#Region "Enums"

    ''' <summary>
    ''' Socket Connection States
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum SocketConnectionState
        Connected
        Disconnected
        Connecting
        Listening
    End Enum

    ''' <summary>
    ''' Which Mode will this Control Act as
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum SocketConnectionMode
        Server
        Client
    End Enum

    ''' <summary>
    ''' Socket Connection Protocol
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum SocketConnectionProtocol
        TCP
        REM For now TCP Only
    End Enum


#End Region


#Region "Events"

    REM But if you are sure it is on same thread you can call it directly
    REM Am attaching each event to a Sub to Handle Cross Threading

    ''' <summary>
    ''' Raises when a new client disconnects
    ''' </summary>
    ''' <param name="SocketID "></param>
    ''' <remarks></remarks>
    Public Event AClientDisconnected(ByVal SocketID As Integer)

    ''' <summary>
    ''' Raises the AClientDisConnected under the Parent Control Thread
    ''' </summary>
    ''' <param name="SocketID "></param>
    ''' <remarks></remarks>
    Private Sub Try_AClientDisConnected(ByVal SocketID As Integer)
        REM Just making sure the parent control is ok before we do anything
        If Me.ParentControl Is Nothing Then Return
        If Me.ParentControl.IsDisposed Then Return
        If Not Me.ParentControl.Created Then Return

        Me.ParentControl.Invoke(Sub() Me.Invoke_AClientDisConnected(SocketID))

    End Sub

    ''' <summary>
    ''' The real invoke inner_Call
    ''' </summary>
    ''' <param name="SocketID"></param>
    ''' <remarks></remarks>
    Private Sub Invoke_AClientDisConnected(ByVal SocketID As Integer)
        RaiseEvent AClientDisconnected(SocketID)
    End Sub



    ''' <summary>
    ''' Raises when a new client connects
    ''' </summary>
    ''' <param name="SocketID "></param>
    ''' <remarks></remarks>
    Public Event AClientConnected(ByVal SocketID As Integer)

    ''' <summary>
    ''' Raises the ClientConnected under the Parent Control Thread
    ''' </summary>
    ''' <param name="SocketID "></param>
    ''' <remarks></remarks>
    Private Sub Try_AClientConnected(ByVal SocketID As Integer)
        REM Just making sure the parent control is ok before we do anything
        If Me.ParentControl Is Nothing Then Return
        If Me.ParentControl.IsDisposed Then Return
        If Not Me.ParentControl.Created Then Return

        Me.ParentControl.Invoke(Sub() Me.Invoke_AClientConnected(SocketID))

    End Sub

    ''' <summary>
    ''' The real invoke inner_Call
    ''' </summary>
    ''' <param name="SocketID"></param>
    ''' <remarks></remarks>
    Private Sub Invoke_AClientConnected(ByVal SocketID As Integer)
        RaiseEvent AClientConnected(SocketID)
    End Sub











    ''' <summary>
    ''' Raises when a New ID has been received from Server
    ''' </summary>
    ''' <remarks></remarks>
    Public Event SocketIDChanged()

    ''' <summary>
    ''' Raises the SocketIDChanged under the Parent Control Thread
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Try_SocketIDChanged()
        REM Just making sure the parent control is ok before we do anything
        If Me.ParentControl Is Nothing Then Return
        If Me.ParentControl.IsDisposed Then Return
        If Not Me.ParentControl.Created Then Return

        Me.ParentControl.Invoke(Sub() Me.Invoke_SocketIDChanged())

    End Sub

    ''' <summary>
    ''' The real invoke inner_Call
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Invoke_SocketIDChanged()
        RaiseEvent SocketIDChanged()
    End Sub


    ''' <summary>
    ''' Raises when there is an error
    ''' </summary>
    ''' <param name="SckMessage"></param>
    ''' <remarks></remarks>
    Public Event SocketErrorMessage(ByVal SckMessage As String)

    ''' <summary>
    ''' Raises the Socket Error Message under the Parent Control Thread
    ''' </summary>
    ''' <param name="SckMessage"></param>
    ''' <remarks></remarks>
    Private Sub Try_SocketErrorMessage(ByVal SckMessage As String)
        REM Just making sure the parent control is ok before we do anything
        If Me.ParentControl Is Nothing Then Return
        If Me.ParentControl.IsDisposed Then Return
        If Not Me.ParentControl.Created Then Return

        Me.ParentControl.Invoke(Sub() Me.Invoke_SocketErrorMessage(SckMessage))

    End Sub

    ''' <summary>
    ''' The real invoke inner_Call
    ''' </summary>
    ''' <param name="SckMessage"></param>
    ''' <remarks></remarks>
    Private Sub Invoke_SocketErrorMessage(ByVal SckMessage As String)
        RaiseEvent SocketLogMessage(SckMessage)
    End Sub


    ''' <summary>
    ''' Raised when the state of this socket changes
    ''' </summary>
    ''' <param name="CurrentState"></param>
    ''' <param name="DebugMessage"></param>
    ''' <remarks></remarks>
    Public Event SocketStateChanged(ByVal CurrentState As SocketConnectionState,
                                    ByVal DebugMessage As String)


    ''' <summary>
    ''' Raises the SocketStateChanged under the Parent Control Thread
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Try_SocketStateChanged(ByVal CurrentState As SocketConnectionState,
                                    ByVal DebugMessage As String)
        REM Just making sure the parent control is ok before we do anything
        If Me.ParentControl Is Nothing Then Return
        If Me.ParentControl.IsDisposed Then Return
        If Not Me.ParentControl.Created Then Return

        Me.ParentControl.Invoke(Sub() Me.Invoke_SocketStateChanged(CurrentState, DebugMessage))

    End Sub

    ''' <summary>
    ''' The real invoke inner_Call
    ''' </summary>
    ''' <remarks>Only call by invoking</remarks>
    Private Sub Invoke_SocketStateChanged(ByVal CurrentState As SocketConnectionState,
                                    ByVal DebugMessage As String)
        RaiseEvent SocketStateChanged(CurrentState, DebugMessage)
    End Sub



    ''' <summary>
    ''' Raises event log messages
    ''' </summary>
    ''' <param name="sckLog"></param>
    ''' <remarks></remarks>
    Public Event SocketLogMessage(ByVal sckLog As String)

    ''' <summary>
    ''' Raises the SocketLogMessage under the Parent Control Thread
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Try_SocketLogMessage(ByVal sckLog As String)
        REM Just making sure the parent control is ok before we do anything
        If Me.ParentControl Is Nothing Then Return
        If Me.ParentControl.IsDisposed Then Return
        If Not Me.ParentControl.Created Then Return

        Me.ParentControl.Invoke(Sub() Me.Invoke_SocketLogMessage(sckLog))

    End Sub

    ''' <summary>
    ''' The real invoke inner_Call. Only Call by invoking
    ''' </summary>
    ''' <remarks>Only call by invoking</remarks>
    Private Sub Invoke_SocketLogMessage(ByVal sckLog As String)
        RaiseEvent SocketLogMessage(sckLog)
    End Sub



#End Region




#Region "Properties"



    ''' <summary>
    ''' For now I will keep this private
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Property Maximum_Connection_Allowed As Integer = 200


    ''' <summary>
    ''' Keep the list of Connected Clients for Fast indexing
    ''' </summary>
    ''' <remarks></remarks>
    Private ClientsOnSever As SortedList(Of Integer, clsClientSocketContainer) = Nothing


    ''' <summary>
    ''' The acting socket as client or server for this class
    ''' </summary>
    ''' <remarks></remarks>
    Private sckSocket As Socket

    ''' <summary>
    ''' I will enclose the sckSocket If am using it for client
    ''' </summary>
    ''' <remarks></remarks>
    Private sckSocketContainer As clsClientSocketContainer = Nothing


    ''' <summary>
    ''' The IContainer passed in by the designer
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Property ParentControl_IContainer As IContainer = Nothing

    Private _ParentControl As Form = Nothing
    ''' <summary>
    ''' GET or Set the  Main Form or Control holding this Component
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ParentControl As Form
        Get
            Return Me._ParentControl
        End Get
        Set(ByVal value As Form)
            If Me.ConnectionState <> SocketConnectionState.Disconnected Then
                RaiseEvent SocketErrorMessage("You cant change this property while the Socket is NOT Disconnected!")
            Else
                Me._ParentControl = value
            End If
        End Set
    End Property


    ''' <summary>
    ''' Pass out the connection state
    ''' </summary>
    ''' <remarks></remarks>
    Private _ConnectionState As SocketConnectionState = SocketConnectionState.Disconnected

    ''' <summary>
    ''' Socket Connection State
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property ConnectionState As SocketConnectionState
        Get
            Return Me._ConnectionState
        End Get
    End Property




    ''' <summary>
    ''' If this is a server .. then fetch the list of connected clients SocketIDs
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property ConnectedClients As List(Of Integer)
        Get
            Return Me.ClientsOnSever.Keys.ToList
        End Get
    End Property


    ''' <summary>
    ''' If this is a client .. Then you need the server IP to Connect to Server
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ServerIP As String

    ''' <summary>
    ''' Ranges between 1 to 32767
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Port As Int16 = 2000


    ''' <summary>
    ''' For Now I will be exposing the Protocols supported by this control
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ConnectionProtocol As SocketConnectionProtocol = SocketConnectionProtocol.TCP


    ''' <summary>
    ''' Listening on Default Local IP
    ''' </summary>
    ''' <remarks></remarks>
    Public Const LocalIP As String = "127.0.0.1"

    ''' <summary>
    ''' Declare how this socket will run
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ConnectionMode As SocketConnectionMode = SocketConnectionMode.Server

    ''' <summary>
    ''' Fetches the Unique ID of this Socket
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property SocketID As Integer
        Get
            Try

                If Me.sckSocket Is Nothing Then Return 0
                If Me.ConnectionMode = SocketConnectionMode.Client Then
                    Return Me.sckSocketContainer.UniqueID_ReceivedFrom_Server

                End If

                Return Me.sckSocket.Handle
            Catch ex As Exception

            End Try

            Return 0
        End Get
    End Property


#End Region



#Region "Methods"


    ''' <summary>
    ''' Converts my exposed protocols to Standard Protocol Enumerations
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getSelectedProtocol() As ProtocolType
        Select Case Me.ConnectionProtocol
            Case Is = SocketConnectionProtocol.TCP
                Return ProtocolType.Tcp
        End Select

        Return ProtocolType.Tcp

    End Function


#Region "Server"

    ''' <summary>
    ''' Make Server Available For Connections
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ServerGoOnline() As Boolean
        'We are running on port 1300
        '

        '   *Possible Errors*
        '   Socket 1300 Already in USE
        '   Socket is Already in Listening State



        Try
            '            Dim IEndpt As IPEndPoint = New IPEndPoint(IPAddress.Parse(LocalIP), Me.Port)
            'Dim IEndpt As IPEndPoint = New IPEndPoint(IPAddress.Parse("192.168.56.101"), Me.Port)
            Dim IEndpt As IPEndPoint = New IPEndPoint(IPAddress.Any, Me.Port)

            Me.sckSocket = New Socket(IEndpt.AddressFamily, SocketType.Stream, Me.getSelectedProtocol)
            Me.sckSocket.Bind(IEndpt)
            '
            'Allow Maximum 100 Pending Connections
            '
            Me.sckSocket.Listen(100)

            REM Continue or Begin to Accept Incoming Connections Asychronously
            Return ServerKeepAccepting()

        Catch ex As Exception

            Me.Try_SocketErrorMessage("Undocumented Error: " & ex.StackTrace)

        End Try

        Return False
    End Function


    ''' <summary>
    ''' Set Server to Keep Accepting Pending Connection Requests
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ServerKeepAccepting() As Boolean
        '   *Possible Errors*
        '   Begin Accept Already Opened
        '
        '
        Try

            Me.sckSocket.BeginAccept(New AsyncCallback(AddressOf ConnectionRequestReceivedFromAClient), Me.sckSocket)

            Try_SocketLogMessage("Server is waiting for client connection request")

            Return True
        Catch ex As Exception

            Me.Try_SocketErrorMessage("Undocumented Error: " & ex.StackTrace)

            Return False
        End Try
    End Function




    ''' <summary>
    ''' Connection Request Received From A Client
    ''' </summary>
    ''' <param name="ar">The Server Object [Socket]</param>
    ''' <remarks>This is on a different thread away from the host</remarks>
    Private Sub ConnectionRequestReceivedFromAClient(ByVal ar As IAsyncResult)
        REM If server socket go offline .. It will try to close the beginAccept
        REM method by entering here

        If Me.sckSocket Is Nothing OrElse Me.ConnectionState = SocketConnectionState.Disconnected Then Return

        Try
            ' Get the listener that handles the client request. 
            Dim listener As Socket = CType(ar.AsyncState, Socket)

            ' End the operation and display the received data on the 
            'console. 
            '

            '
            'ClientSocket is Temporary and is Not Indexed . . .
            ' When system name is gotten, it will be indexed
            Dim ClientSocket As Socket = listener.EndAccept(ar)

            REM Temporary here Socket is no more accepting connections from other client
            REM We will be using socket handle here to uniquely identify each client
            REM Send the SocketHandle to the client .. Incase it needs it
            REM add the client to collection



            '
            Me.Try_SocketLogMessage("A client connected!")

            '
            ' Start Receiving From the Client, Send ID to Client
            '
            Dim ClientReadingClass As New clsClientSocketContainer(ClientSocket)

            Me.ClientKeepReceivingMessage(ClientReadingClass)


            REM Send the connecting client's ID
            basSocketHelper.SendCommand(ClientReadingClass.ClientSocket,
                           ClientReadingClass.SocketKey,
                           "HereIsYourID")


            Me.Try_SocketLogMessage("Sent ID to Client: " & ClientReadingClass.SocketKey)


            REM Add to Client List
            Me.ClientsOnSever.Add(ClientReadingClass.SocketKey, ClientReadingClass)

            Me.Try_SocketLogMessage("Total Connections: " & Me.ClientsOnSever.Count)

            Me.Try_AClientConnected(ClientReadingClass.SocketKey)


            '
            ' If I want it to continue accepting .. I have to turn on the begin accept again
            Me.ServerKeepAccepting()



        Catch ex As ObjectDisposedException

            REM This part will not be called again

            '
            'Currently, I cant detect a way to know the server closed than exception
            REM Server socket is shutting down

            Me.Try_SocketErrorMessage("Server has gone offline")



        Catch ex As Exception


        End Try
    End Sub 'Client Connection Request Recieved


    ''' <summary>
    ''' Stream is received From Client.
    ''' </summary>
    ''' <param name="ar"></param>
    ''' <remarks>This is on a different thread away from the host</remarks>
    Private Sub MessageReceivedFromClient(ByVal ar As IAsyncResult)

        'Information Received here is on another thread

        REM Make it able to captivate message greater than 1024 kb by receiving asyncronously until no byte is available
        Dim ClientReadingClass As clsClientSocketContainer = CType(ar.AsyncState, clsClientSocketContainer)
        Dim ClientSocket As Socket = ClientReadingClass.ClientSocket


        '
        '
        'If Client has shutdown It disconnects before calling endreceive function itself
        'Most times we are not that fast to catch it so it goes down as exception

        Try


            'Say We Have Received the bytes and Stored it in Buffer [ClientReadingClass]
            Dim ByteRecieved As Integer = ClientSocket.EndReceive(ar)

            'If any byte was received
            If ByteRecieved > 0 Then


                Call ProcessServerCommand(
                            ClientReadingClass,
                            basSocketHelper.ReceiveCommand(
                                ByteRecieved,
                                ClientReadingClass
                                )
                            )


                'Keep Receiving from client
                ClientKeepReceivingMessage(ClientReadingClass)

            End If

        Catch ex As SocketException
            REM I assumed if error occurred here it means a client is disconnecting
            'ex returns nothing
            'If ex.SocketErrorCode = SocketError.ConnectionReset Then
            'Client Application is Off or Client System Shut Down
            'Refer to shutdown process

            'End If
            'Clean Up SocketClass and Remove Item on List
            'First Adjust the counter
            ' ''Me.aClientIsLeaving(ClientReadingClass.SocketKey)

            REM Client listening for messages sockets closed

            ' Debug.Print("Message Received From Client: " & ex.StackTrace)
            Me.Try_SocketLogMessage(
                String.Format(
                    "Client {0}: is shutting down",
                    ClientReadingClass.SocketKey
                    )
                )


            REM Dispose Client and remove from bank list
            Me.ClientsOnSever.Remove(ClientReadingClass.SocketKey)

            Me.Try_AClientDisConnected(ClientReadingClass.SocketKey)


            ClientReadingClass.Dispose()



        Catch ex As Exception

            Me.Try_SocketErrorMessage("Undocumented Error: " & ex.StackTrace)



        End Try
    End Sub 'Read_Callback



    ''' <summary>
    ''' Set Client Socket To keep receiving messages
    ''' </summary>
    ''' <param name="ClientClass"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ClientKeepReceivingMessage(
                                            ByRef ClientClass As clsClientSocketContainer
                                            ) As Boolean

        Try
            ClientClass.ClientSocket.BeginReceive(ClientClass.buffer, 0, clsClientSocketContainer.BUFFER_SIZE, 0,
                              New AsyncCallback(AddressOf MessageReceivedFromClient),
                              ClientClass)

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function



    Private Function ServerGoOffline() As Boolean
        '   Since am using lsvMainClients to store the connected clients directly
        '   Saving their socket information in each item

        '   So if Server is to go offline, First 
        '   Block incoming and outgoing transaction on server
        '   Stop listening

        'I am thinking of not disposing clients here even though server is shutdown
        'Because they have nothing in common. Server Shutdown only means no more accepting new connection
        '
        'Clients can be shutdown from options on client or when it goes off
        '
        '' ''   Now Remove and Dispose Each item on the list
        '' ''       On Dispose of each item, let them dispose their socket indexes

        REM Incase an error occurs .. restore previous state
        Dim PrevState As SocketConnectionState = Me.ConnectionState

        Try

            If Me.sckSocket IsNot Nothing Then
                With Me.sckSocket
                    '' Only use shutdown for a connected Socket. Not a listening socket
                    '.Shutdown(SocketShutdown.Both)
                    Me._ConnectionState = SocketConnectionState.Disconnected REM Because of async method
                    .Close()



                End With

            End If

            Return True

        Catch ex As Exception
            Me._ConnectionState = PrevState
        End Try
        Return False
    End Function

    ''' <summary>
    ''' Handles the communication data between server and client and decides if it needs to relay it to user [as what to do]
    ''' </summary>
    ''' <param name="clientReadingClass"></param>
    ''' <param name="MessageReceived"></param>
    ''' <remarks></remarks>
    Private Sub ProcessServerCommand(ByRef clientReadingClass As clsClientSocketContainer,
                               ByVal MessageReceived As String()
                               )
        'Be Consistent With Your Command Name Because It is Case Sensitive
        REM {{EPCommand}}{{ProgrammerCommand}}{{MessageContent}}

        REM I have to check how i process the message because it could be a file and not a string
        REM For now we are dealing with strings
        If MessageReceived IsNot Nothing Then
            Me.Try_SocketLogMessage(
                String.Format(
                    "Client {0}: {1}", clientReadingClass.SocketKey, MessageReceived(0)
                    )
                )
        Else
            Me.Try_SocketLogMessage(
                String.Format(
                    "Client {0}: Empty Message", clientReadingClass.SocketKey
                    )
                )
        End If

    End Sub



#End Region


#Region "Client"

    ''' <summary>
    ''' Disconnect Client from Server
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function DisconnectClient() As Boolean
        Try

            Me.sckSocketContainer.Dispose()
            If Me.sckSocket IsNot Nothing Then
                If Me.sckSocket.Connected Then Me.sckSocket.Close()
                Me.sckSocket = Nothing

            End If

            Return True

        Catch ex As Exception

            Return False

        End Try

    End Function

    ''' <summary>
    ''' The result of the Async Func Begin Connect
    ''' </summary>
    ''' <param name="ar"></param>
    ''' <remarks></remarks>
    Private Sub DoConnectToServerResult(ByVal ar As IAsyncResult)
        ' Get the listener that handles the client request. 
        Dim connecter As Socket = CType(ar.AsyncState, Socket)

        ' End the operation and display the received data on the 
        'console. 
        Try
            connecter.EndConnect(ar)

            REM If successful no error will occur

            Me.sckSocketContainer = New clsClientSocketContainer(connecter)

            KeepReceivingMessageFromServer(sckSocketContainer)

            


            Me.Try_SocketLogMessage("Client Connected")
            Me.Try_SocketStateChanged(SocketConnectionState.Connected, "Connected to Server on Port: " & Me.Port)
            Me._ConnectionState = SocketConnectionState.Connected


        Catch ex As SocketException
            REM No Connection was made

            REM If I want to dispose the client i will just dispose current socket
            Me.Try_SocketLogMessage(ex.Message)
            Me.Try_SocketStateChanged(SocketConnectionState.Disconnected, "Connection to Server failed.")
            Me._ConnectionState = SocketConnectionState.Disconnected


        Catch ex As Exception
            'Error Occurred Could Not Connect
            'Keep Trying
            Me.Try_SocketErrorMessage("Undocumented Error: " & ex.StackTrace)

        End Try

    End Sub


    ''' <summary>
    ''' Handles Messages Received From Server
    ''' </summary>
    ''' <param name="ar"></param>
    ''' <remarks></remarks>
    Private Sub MessageReceivedFromServer(ByVal ar As IAsyncResult)
        Dim ClientReadingClass As clsClientSocketContainer = CType(ar.AsyncState, clsClientSocketContainer)
        Dim ClientSocket As Socket = ClientReadingClass.ClientSocket


        '
        '
        'If Server has shutdown
        '
        ''        'It blocks before shutting down
        ''        If Not ClientSocket.Connected And ClientSocket.Blocking Then
        ''ServerSocketDownProcess:
        ''            'Client is Shutting Down or has shut down
        ''            'Completing the shutdown process on this place
        ''            'Remove client from lsvMain list
        ''            'Decompose this class with its socket
        ''            ''msg("Server has shut down")
        ''            ''msg("Creating New Client .. ")
        ''            ''msg("Waiting for you to click connect")
        ''            'MySocket = New SocketReadingStateObject()
        ''            ' Me.ServerStatus = MyConnectionStatus.Disconnected
        ''            Debug.Print("Client disconnecting")
        ''            Return
        ''        End If


        '
        'An exception occurrs here .. An existing connection was forcibly closed by the remote operation
        'Which pass the close checking parameters
        '
        Dim ByteRecieved As Integer
        Try
            If ClientReadingClass IsNot Nothing AndAlso
                Not ClientReadingClass.isDisposed AndAlso ClientSocket IsNot Nothing Then
                'Say We Have Received the bytes and Stored it in Buffer [ClientReadingClass]
                ByteRecieved = ClientSocket.EndReceive(ar)
            End If

        Catch ex As ObjectDisposedException
            REM Socket has been disposed 
            REM Meaning no longer available
            REM This calls under client

            REM This happens if the Client Disconnects Manually

        Catch ex As SocketException
            REM This happens only when Server Shuts Down or Something happens to server pc
            If ex.SocketErrorCode = SocketError.ConnectionReset Then
                'Server Application is Off or Server System Shut Down
                'Refer to shutdown process
                Me.Try_SocketLogMessage("Connection Reset")
                Me.Stop()

            End If
        Catch ex As Exception

        End Try

        'If any byte was received
        If ByteRecieved > 0 Then


            Call ProcessClientCommand(
                        ClientReadingClass,
                        basSocketHelper.ReceiveCommand(
                            ByteRecieved,
                            ClientReadingClass
                            )
                        )



            'Keep Receiving from server
            Me.KeepReceivingMessageFromServer(ClientReadingClass)

        End If



    End Sub 'Read_Callback

    ''' <summary>
    ''' Process Command Received From Server
    ''' </summary>
    ''' <param name="clientReadingClass"></param>
    ''' <param name="MessageReceived"></param>
    ''' <remarks></remarks>
    Private Sub ProcessClientCommand(ByVal clientReadingClass As clsClientSocketContainer,
                              ByVal MessageReceived As String()
                              )

        'Be Consistent With Your Command Name Because It is Case Sensitive
        REM HereIsYourID
        Dim CommandReceived As String = MessageReceived(0)

        Select Case CommandReceived

            Case Is = "HereIsYourID"
                clientReadingClass.UniqueID_ReceivedFrom_Server = Val(MessageReceived(1))
                Try_SocketIDChanged()



        End Select



    End Sub


    ''' <summary>
    ''' Keep Receiving Messages From Server
    ''' </summary>
    ''' <param name="ClientClass"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function KeepReceivingMessageFromServer(
                                            ByRef ClientClass As clsClientSocketContainer
                                            ) As Boolean

        Try
            ClientClass.ClientSocket.BeginReceive(ClientClass.buffer, 0, clsClientSocketContainer.BUFFER_SIZE, 0,
                              New AsyncCallback(AddressOf MessageReceivedFromServer),
                              ClientClass)

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function


    ''' <summary>
    ''' Initiate Begin Connect Function
    ''' </summary>
    ''' <remarks></remarks>
    Private Function TryConnectingToServer() As Boolean
        Try
            'Get a fresh copy .. because when a socket is closed it can not be used again

            Dim IEndpt As IPEndPoint = New IPEndPoint(
                                       IPAddress.Parse(Me.ServerIP),
                                       Me.Port
                                       )


            Me.sckSocket = New Socket(IEndpt.AddressFamily, SocketType.Stream, Me.getSelectedProtocol)


            Me.sckSocket.BeginConnect(IEndpt, New AsyncCallback(AddressOf Me.DoConnectToServerResult), Me.sckSocket)

            Return True

        Catch ex As Exception

            Me.Try_SocketErrorMessage("Client Try Connect Failed: " & ex.StackTrace)

            Return False

        End Try
    End Function








#End Region



    ''' <summary>
    ''' Starts the socket
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub [Start]()

        If Me.ParentControl Is Nothing Then
            RaiseEvent SocketErrorMessage("Please SET the ParentControl Property on the Socket")
            Return
        End If

        Select Case Me.ConnectionMode

            Case Is = SocketConnectionMode.Server
                If Me.ConnectionState = SocketConnectionState.Disconnected Then
                    RaiseEvent SocketLogMessage("Server is going online ...")
                    RaiseEvent SocketStateChanged(SocketConnectionState.Connecting, "Trying to listen on port " & Me.Port)

                    If Not Me.ServerGoOnline() Then
                        RaiseEvent SocketLogMessage("Server Failed to go online ...")
                        Me._ConnectionState = SocketConnectionState.Disconnected
                        RaiseEvent SocketStateChanged(Me.ConnectionState, "Server could not listen on port " & Me.Port)

                    Else
                        RaiseEvent SocketLogMessage("Server is online")
                        Me._ConnectionState = SocketConnectionState.Connected
                        RaiseEvent SocketStateChanged(Me.ConnectionState, "Server is listening on port " & Me.Port)

                    End If

                Else

                    REM And it is going to remain in it's current form
                    RaiseEvent SocketErrorMessage("Server is NOT disconnected!")


                End If

            Case Is = SocketConnectionMode.Client


                If Me.ConnectionState = SocketConnectionState.Disconnected Then
                    RaiseEvent SocketLogMessage(String.Format("Connecting to server {0} on port {1} ...", Me.ServerIP, Me.Port))
                    Me._ConnectionState = SocketConnectionState.Connecting REM To Avoid more than one request
                    If Not Me.TryConnectingToServer() Then
                        RaiseEvent SocketLogMessage("Client could not connect to server ...")
                        Me._ConnectionState = SocketConnectionState.Disconnected
                        RaiseEvent SocketStateChanged(Me.ConnectionState, "Connection to Server failed.")

                    Else
                        REM Trying to connect asycn successful but doesnt mean connected
                        RaiseEvent SocketLogMessage("Opening Port on Server ...")
                    End If
                ElseIf Me.ConnectionState = SocketConnectionState.Connecting Then
                    RaiseEvent SocketLogMessage("Attempting multi-request")
                    RaiseEvent SocketErrorMessage("Please be patient ... Trying to connect to Server")

                Else

                    REM And it is going to remain in it's current form
                    RaiseEvent SocketErrorMessage("Client is NOT disconnected!")


                End If




        End Select
    End Sub

    ''' <summary>
    ''' Stops the Socket
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub [Stop]()

        Select Case Me.ConnectionMode

            Case Is = SocketConnectionMode.Server

                If Not Me.ConnectionState = SocketConnectionState.Disconnected Then
                    If Me.ServerGoOffline Then

                        RaiseEvent SocketErrorMessage("Server is now offline")
                        Me._ConnectionState = SocketConnectionState.Disconnected
                        RaiseEvent SocketStateChanged(Me.ConnectionState, "Server Socket Went offline")
                    Else

                        RaiseEvent SocketErrorMessage("Server could not shutdown")

                    End If
                Else

                    RaiseEvent SocketErrorMessage("Server is already Offline")


                End If

            Case Is = SocketConnectionMode.Client


                If Not Me.ConnectionState = SocketConnectionState.Disconnected Then
                    If Me.DisconnectClient Then

                        Me.Try_SocketErrorMessage("Client is now offline")
                        Me._ConnectionState = SocketConnectionState.Disconnected
                        RaiseEvent SocketStateChanged(Me.ConnectionState, "Client Socket went offline")


                    Else

                        RaiseEvent SocketErrorMessage("Client could not shutdown")

                    End If
                Else

                    RaiseEvent SocketErrorMessage("Client is Already Disconnected!")


                End If



        End Select


    End Sub



#End Region




#Region "IDisposable Support"

    REM ISite Not Functional Yet -------------------------------------------
    REM Am making Private for now so it doesnt interfare with the Usage
    REM Because if user tries to make it none on design mode .. It will cause error
    Private __Site As ISite
    Private Property Site As System.ComponentModel.ISite Implements System.ComponentModel.IComponent.Site
        Get
            Return __Site
        End Get
        Set(ByVal value As System.ComponentModel.ISite)
            __Site = value
        End Set
    End Property

    REM ----------------------------------------------------------------------------




    Public Event Disposed As System.EventHandler Implements IComponent.Disposed

    Private disposedValue As Boolean ' To detect redundant calls

    ' IDisposable
    Protected Overridable Sub Dispose(ByVal disposing As Boolean)
        If Not Me.disposedValue Then
            If disposing Then
                ' TODO: dispose managed state (managed objects).
            End If

            ' TODO: free unmanaged resources (unmanaged objects) and override Finalize() below.
            ' TODO: set large fields to null.
        End If
        Me.disposedValue = True
    End Sub

    ' TODO: override Finalize() only if Dispose(ByVal disposing As Boolean) above has code to free unmanaged resources.
    'Protected Overrides Sub Finalize()
    '    ' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
    '    Dispose(False)
    '    MyBase.Finalize()
    'End Sub

    ' This code added by Visual Basic to correctly implement the disposable pattern.
    Public Sub Dispose() Implements IDisposable.Dispose
        ' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
        Dispose(True)
        GC.SuppressFinalize(Me)
    End Sub


#End Region


End Class
