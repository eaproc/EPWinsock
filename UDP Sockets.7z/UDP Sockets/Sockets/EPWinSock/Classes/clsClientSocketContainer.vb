﻿Imports System.Net.Sockets

''' <summary>
''' Encase the client socket so we can extend it and have more functions without extending the socket itself
''' </summary>
''' <remarks></remarks>
Friend Class clsClientSocketContainer
    Implements IDisposable

    ' This Algorithm helps fast indexing
    '
#Region "Constructors"
    ''Sub New()

    ''End Sub
    Sub New(ByVal ClientSocket As Socket)
        Me.ClientSocket = ClientSocket
    End Sub

    ''Sub New(ByVal IEndpt As IPEndPoint)
    ''    Me.workSocket = New Socket(IEndpt.AddressFamily, SocketType.Stream, ProtocolType.Tcp)
    ''End Sub

#End Region

#Region "Destructors"

    ''' <summary>
    ''' Indicates if this class is disposed
    ''' </summary>
    ''' <remarks></remarks>
    Private Disposed As Boolean = False
    ''' <summary>
    ''' Indicates if this class is disposed
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property isDisposed As Boolean
        Get
            Return Me.Disposed
        End Get
    End Property

    Public Sub Dispose() Implements IDisposable.Dispose

        Dispose(True)
        GC.SuppressFinalize(Me)
    End Sub
    Protected Overridable Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            Me.Disposed = True REM Because of Async events

            If Me.ClientSocket IsNot Nothing Then _
                If Me.ClientSocket.Connected Then Me.ClientSocket.Close()
            Me.ClientSocket = Nothing


        End If

    End Sub
    Protected Overrides Sub Finalize()
        Dispose(False)
    End Sub
#End Region


    ''' <summary>
    ''' Socket Information We are Transferring. Also I will use this to access client list on ClientsSockets Collection
    ''' </summary>
    ''' <remarks></remarks>
    Public Property ClientSocket As Socket = Nothing

    ''' <summary>
    ''' Maximum Size of data to send on the Socket Layer Per Time
    ''' </summary>
    ''' <remarks></remarks>
    Public Const BUFFER_SIZE As Integer = 1024

    ''' <summary>
    ''' Contains Last Segment of Information Received in Array of Bytes
    ''' </summary>
    ''' <remarks></remarks>
    Public buffer(BUFFER_SIZE) As Byte

    REM Normally as Server, All Socket save for clients has their keys equivalent to their handles
    REM But has a Client It's key is the ID sent from the Server
    ''' <summary>
    ''' Unique Key to Access this Client
    ''' </summary>
    ''' <remarks></remarks>
    Public ReadOnly Property SocketKey As Integer
        Get

            If Me.ClientSocket IsNot Nothing Then Return Me.ClientSocket.Handle.ToInt32
            Return 0
        End Get
    End Property


    ''' <summary>
    ''' This will be main effectuated on Client. Change only when Server sents a new one
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property UniqueID_ReceivedFrom_Server As Integer = 0




End Class
