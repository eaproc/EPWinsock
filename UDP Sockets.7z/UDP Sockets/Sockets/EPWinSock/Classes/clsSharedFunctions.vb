﻿Imports System.Net.NetworkInformation

''' <summary>
''' Exposes some functions to the whole project
''' </summary>
''' <remarks>This is a static Class ==Equivalent to Module</remarks>
Public Class clsSharedFunctions

    ''' <summary>
    ''' Check Whether the IP Entered is in a correct format [IP v4]. 
    ''' Min: 0.0.0.0
    ''' Max: 255.255.255.255
    ''' </summary>
    ''' <param name="IP">Ip Address to check</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function parseIP(ByVal IP As String) As Boolean
        REM 3 Locations of (.)
        REM [.] must not start and must not end
        REM Must not contain [..]
        REM Must Contain 4 Fragments
        REM Each Fragment Must not exceed a byte 255
        REM Run thru each fragment, Each must not exceed Max: 3chars and Min: 1
        REM All Fragment must be numeric


        If IP.Length = 0 Then Return False
        If IP.Substring(0, 1).Equals(".") Then Return False
        If IP.Substring(IP.Length - 1, 1).Equals(".") Then Return False
        If IP.IndexOf("..") > 0 Then Return False

        Dim IPSegs() As String = Split(IP, ".")
        If IPSegs.Length <> 4 Then Return False


        REM Let us check the content of each segment

        For Each Segment As String In IPSegs
            If Segment Is Nothing Then Return False
            REM Trim incase of space
            If Segment.Length > 3 Or Segment.Trim.Length < 1 Then Return False

            REM Assume no space and still meet the length
            If Not IsNumeric(Segment) Then Return False

            REM Since it is numeric, check if it is a byte value
            If Val(Segment) > 255 Then Return False

        Next




        REM If all segments passed the test then return true
        Return True
    End Function

    ''' <summary>
    ''' Returns this system IP Address
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared Function getMyIpAddress() As String

        Try
            If My.Computer.Network.IsAvailable Then

                For Each NIC As NetworkInterface In NetworkInterface.GetAllNetworkInterfaces


                    If NIC.NetworkInterfaceType = NetworkInterfaceType.Wireless80211 Or
                        NIC.NetworkInterfaceType = NetworkInterfaceType.Ethernet Then


                        For Each ip As UnicastIPAddressInformation In NIC.GetIPProperties().UnicastAddresses

                            If ip.Address.AddressFamily = System.Net.Sockets.AddressFamily.InterNetwork Then


                                Return ip.Address.ToString()


                            End If

                        Next


                    End If




                Next

            End If


            Return "0.0.0.0"

        Catch ex As Exception
            Return "0.0.0.0"
        End Try
    End Function


End Class
