﻿Imports System.Net.Sockets
Imports System.Net
Imports System.Text

Imports EPRO.Library.v3._5.Network

Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        For Each i In System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces()
            For Each ua In i.GetIPProperties().UnicastAddresses
                Debug.WriteLine(ua.Address)
            Next
        Next

    End Sub

    Private Sub cmdConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdConnect.Click

        'Me.EpWinSock1.Start()

        Try

            For Each p In Network.GetNetworkInterfacesWithValidIPv4()
                Dim pBroadcastNIC = p
                Dim pIps = Network.getAllIpDetailsForNIC(pBroadcastNIC)
                Dim pBroadcastIP = pIps.FirstOrDefault().BroadcastAddressDecimalNotation.ToString()

                Dim s As New Socket(AddressFamily.InterNetwork, SocketType.Dgram,
                                        ProtocolType.Udp)
                Dim broadcast As IPAddress = IPAddress.Parse(pBroadcastIP)
                'Dim broadcast As IPAddress = IPAddress.Broadcast

                Dim sendbuf As Byte() = Encoding.ASCII.GetBytes("Hello Dude!")
                Dim ep As New IPEndPoint(broadcast, 11000)
                s.SendTo(sendbuf, ep)
                Me.EpWinSock1_SocketLogMessage("Message sent to the broadcast address on " & pBroadcastNIC.Description)

            Next

        Catch ex As Exception
            Me.EpWinSock1_SocketErrorMessage(ex.Message)
        End Try

    End Sub



    Private Sub EpWinSock1_SocketErrorMessage(ByVal SckMessage As String)



        Me.lstServerResponse.Items.Add(
           String.Format("Error Message: {0}", SckMessage)
           )

        Me.lstServerResponse.SelectedIndex = Me.lstServerResponse.Items.Count - 1

    End Sub

    Private Sub EpWinSock1_SocketLogMessage(ByVal sckLog As String)
        Me.lstServerResponse.Items.Add(
           String.Format("Log: {0}", sckLog)
           )
        Me.lstServerResponse.SelectedIndex = Me.lstServerResponse.Items.Count - 1

    End Sub

    Private Sub cmdDisconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDisconnect.Click
        'Me.EpWinSock1.Stop()
    End Sub


End Class
