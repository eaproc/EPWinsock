﻿Imports System.Net.Sockets
Imports System.Net
Imports System.Text


Imports EPRO.Library.v4.Shell


Public Class Form1

    Private Sub cmdSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSend.Click
        Me.lstServerResponse.Items.Add(
            String.Format("ME: {0}", txtMessage.Text)
            )

        Me.lstServerResponse.SelectedIndex = Me.lstServerResponse.Items.Count - 1

        txtMessage.Text = vbNullString
    End Sub

    Private Sub EpWinSock1_SocketErrorMessage(ByVal SckMessage As String)
        Me.lstServerResponse.Items.Add(
           String.Format("Server: {0}", SckMessage)
           )

        Me.lstServerResponse.SelectedIndex = Me.lstServerResponse.Items.Count - 1
    End Sub


    Private Sub EpWinSock1_SocketLogMessage(ByVal sckLog As String)
        If Me.InvokeRequired Then
            Me.Invoke(Sub() EpWinSock1_SocketLogMessage(sckLog))
            Return
        End If
        Me.lstServerResponse.Items.Add(
           String.Format("Server: {0}", sckLog)
           )

        Me.lstServerResponse.SelectedIndex = Me.lstServerResponse.Items.Count - 1
    End Sub


    Private Sub cmdConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdConnect.Click
        'EpWinSock1.Start()


        Dim pThr As New Threading.Thread(AddressOf Me.ReceiveIfAvailable) With {.IsBackground = True,
                                                                               .Name = "pThread"
                                                                              }
        pThr.Start()




    End Sub

    Private Sub ReceiveIfAvailable()

        Dim listener As New UdpClient(listenPort)
        Dim groupEP As New IPEndPoint(IPAddress.Any, listenPort)
        Try

            While Not Me.IsDisposed

                Try

                    Me.EpWinSock1_SocketLogMessage("Waiting for broadcast")
                    Dim bytes As Byte() = listener.Receive(groupEP)
                    Me.EpWinSock1_SocketLogMessage("Received broadcast from {0} :" & _
                        groupEP.ToString()
                        )
                    Me.EpWinSock1_SocketLogMessage( _
                        Encoding.ASCII.GetString(bytes, 0, bytes.Length))
                    Me.EpWinSock1_SocketLogMessage(String.Empty)
                Catch ex As Exception
                    EpWinSock1_SocketLogMessage(ex.ToString())
                End Try

                Threading.Thread.Sleep(2000)
            End While

        Catch ex As Exception
            Debug.Print(ex.Message)
        Finally
            listener.Close()
        End Try
    End Sub

    Private Const listenPort As Integer = 1303

    'Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
    '    Dim listener As New UdpClient(listenPort)
    '    Dim groupEP As New IPEndPoint(IPAddress.Any, listenPort)
    '    Try

    '        Me.EpWinSock1_SocketLogMessage("Waiting for broadcast")
    '        Dim bytes As Byte() = listener.Receive(groupEP)
    '        Me.EpWinSock1_SocketLogMessage("Received broadcast from {0} :" & _
    '            groupEP.ToString()
    '            )
    '        Me.EpWinSock1_SocketLogMessage( _
    '            Encoding.ASCII.GetString(bytes, 0, bytes.Length))
    '        Me.EpWinSock1_SocketLogMessage(String.Empty)
    '    Catch ex As Exception
    '        EpWinSock1_SocketLogMessage(ex.ToString())
    '    Finally
    '        listener.Close()
    '    End Try
    'End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try

        
        '
        ' Add Firewall Inbound if missing
        ' Requires Administrator Priviledge
        '
        Dim FirewallName As String = "Test UDP Firewall"

            'Firewall.AddApplicationUDPEnableException(Application.ProductName, Application.ExecutablePath)
        If Not Firewall.isInboundPortExceptionValid(FirewallName, listenPort.ToString()) Then
            Firewall.createInboundPortExceptions(FirewallName, "My Test Firewall", listenPort.ToString(), Firewall.TrafficProtocols.UDP)
        End If



        Catch ex As Exception
            Debug.Print(ex.Message)
        End Try





    End Sub
End Class
